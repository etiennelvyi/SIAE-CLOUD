#include <pthread.h>
#include <time.h>
#include <stdio.h>
#include <semaphore.h>
void  add_timespec (struct timespec *s,
                   const struct timespec *t1,
                   const struct timespec *t2)
/* s = t1+t2 */
{
 s->tv_sec  = t1->tv_sec  + t2->tv_sec;
 s->tv_nsec = t1->tv_nsec + t2->tv_nsec;
 s->tv_sec += s->tv_nsec/1000000000;
 s->tv_nsec %= 1000000000;
}


void *t1(void * unused) { /* A thread is a function that will be run using pthread_create */
	/* local variables */
	struct timespec release; /* will contain the release date */
	struct timespec period; /* contains the period */
	struct timespec remain; /* used for clock_nanosleep */
	period.tv_nsec=0 ; /* le champ en nanosecondes vaut 1 seconde */
	period.tv_sec=1 ; /* le champ en secondes vaut 0 */
	/* initialization */
	clock_gettime(CLOCK_REALTIME,&release); /* release=current time */
	for (;;) { /* do forever */
		/* task body */
		printf("T1\n");
		add_timespec(&release, &release, &period); /* computing next release time */
		clock_nanosleep(CLOCK_REALTIME,TIMER_ABSTIME,&release,&remain); /* wait until release time */
	}
}


void *t2(void * unused) {
	struct timespec release; /* will contain the release date */
	struct timespec period; /* contains the period */
	struct timespec remain; /* used for clock_nanosleep */
	period.tv_nsec=0 ; /* le champ en nanosecondes vaut 1 seconde */
	period.tv_sec=1 ; /* le champ en secondes vaut 0 */
	int read;
	for (;;) {
		scanf("%d",&read);
		clock_gettime(CLOCK_REALTIME,&release); /* release=current time */
		add_timespec(&release, &release, &period); /* computing next release time */
		printf("T2:%d\n",read);
		clock_nanosleep(CLOCK_REALTIME,TIMER_ABSTIME,&release,&remain); /* wait until release time */
	}
}

void main() {
	pthread_t T1,T2;
	pthread_create(&T1, 0,t1,0); /* creates the thread executing T1 */
	pthread_create(&T2, 0,t2,0);
	pthread_join(T1,0); /* Waits for T1 to terminate */
}
