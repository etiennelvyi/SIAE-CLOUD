#include <pthread.h>
#include <time.h>
#include <stdio.h>
#include <semaphore.h>
#include "mymailbox.h"
void  add_timespec (struct timespec *s,
                   const struct timespec *t1,
                   const struct timespec *t2)
/* s = t1+t2 */
{
 s->tv_sec  = t1->tv_sec  + t2->tv_sec;
 s->tv_nsec = t1->tv_nsec + t2->tv_nsec;
 s->tv_sec += s->tv_nsec/1000000000;
 s->tv_nsec %= 1000000000;
}


void *t1(void * unused) { /* A thread is a function that will be run using pthread_create */
	/* local variables */
	struct timespec release; /* will contain the release date */
	struct timespec period; /* contains the period */
	struct timespec remain; /* used for clock_nanosleep */
	period.tv_nsec=0 ; /* le champ en nanosecondes vaut 1 seconde */
	period.tv_sec=1 ; /* le champ en secondes vaut 0 */
	/* initialization */
	clock_gettime(CLOCK_REALTIME,&release); /* release=current time */
	for (;;) { /* do forever */
		/* task body */
		printf("T1\n");
		add_timespec(&release, &release, &period); /* computing next release time */
		clock_nanosleep(CLOCK_REALTIME,TIMER_ABSTIME,&release,&remain); /* wait until release time */
	}
}

mailbox MB;

void *t2(void * unused) {
	struct timespec release; /* will contain the release date */
	struct timespec period; /* contains the period */
	struct timespec remain; /* used for clock_nanosleep */
	period.tv_nsec=0 ; /* le champ en nanosecondes vaut 1 seconde */
	period.tv_sec=1 ; /* le champ en secondes vaut 0 */
	int read;
	for (;;) {
		scanf("%d",&read);
		clock_gettime(CLOCK_REALTIME,&release); /* release=current time */
		add_timespec(&release, &release, &period); /* computing next release time */
		mailbox_send(MB,(char*)&read);
		printf("T2:%d\n",read);
		clock_nanosleep(CLOCK_REALTIME,TIMER_ABSTIME,&release,&remain); /* wait until release time */
	}
}
sem_t synchro;
void *t3(void * unused) {
	int received;
	for (;;) {
		mailbox_receive(MB,(char*)&received);
		printf("T3:%d\n",received);
		if (received%2) {
			sem_post(&synchro);
		}
	}		
}

void *t4() {
	for (;;) {
		sem_wait(&synchro);
		printf("T4 executes since number is odd\n");
	}
}
void main() {
	pthread_t T1,T2,T3,T4;
	MB=mailbox_init(sizeof(int));
	sem_init(&synchro,0,0);
	pthread_create(&T1, 0,t1,0); /* creates the thread executing T1 */
	pthread_create(&T2, 0,t2,0);
	pthread_create(&T3, 0,t3,0);
	pthread_create(&T4,0,t4,0);
	pthread_join(T1,0); /* Waits for T1 to terminate */
}
