
#ifndef _SHDATA_H_
#define _SHDATA_H_
#include <pthread.h>

typedef struct s_shareddata {
	int value;
	pthread_mutex_t mutex;
} *shareddata;

shareddata SD_init();
void SD_write(shareddata sd, int v);
int SD_read(shareddata sd);
#endif
