#include "SharedData.h"
#include "stdlib.h"
shareddata SD_init() {
	shareddata sd;
	sd=(shareddata)malloc(sizeof(struct s_shareddata));
	(*sd).value=0;
	pthread_mutex_init(&((*sd).mutex),0);
	return sd;
}

void SD_write(shareddata sd, int v) {
    pthread_mutex_lock (&(*sd).mutex);
	(*sd).value=v;
	pthread_mutex_unlock (&(*sd).mutex);
}

int SD_read(shareddata sd) {
	int v;
    pthread_mutex_lock (&(*sd).mutex);
	v=(*sd).value;
	pthread_mutex_unlock (&(*sd).mutex);
	return v;
}
