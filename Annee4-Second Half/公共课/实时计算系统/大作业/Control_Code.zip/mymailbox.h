/*
 * Mailbox of size one with loss
 * (c) Emmanuel Grolleau - 2015
 */
#ifndef _MYMAILBOX_H_
#define _MYMAILBOX_H_

#include <pthread.h>
/* Mailbox of size 1, with loss: previous message is replaced by new message if mailbox is full */
typedef struct s_mailbox {
	char * buf;/* buffer dynamically allocated by mailbox_init */
	unsigned char empty;/* state of the mailbox */
	pthread_mutex_t mutex;/* Mutex insuring mutual exclusion for the mailbox */
	pthread_cond_t not_empty;/* used to signal when the mailbox is not empty */
	unsigned message_size;/* size of a message */
} *mailbox;

mailbox mailbox_init(const unsigned msg_size);
/* Creates and initializes a mailbox
Requires: msg_size>0
Returns: the mailbox if success, 0 else */

int mailbox_receive(mailbox m, char *buf);
/* Wait for a message in mailbox m
Blocking function
Requires: m is an initialized mailbox
          size(buf) >= maiblox message_size
Insures: after completion, buf contains the received message
Returns: message_size */

int mailbox_send(mailbox m, const char *buf);
/* Sends a message in the mailbox m
If m is full, the previous message is replaced by the new message
Requires: m initialized mailbox
          size(buf) >= mailbox message_size
Insures: the message in buf is added to the mailbox
Returns: message_size */

void mailbox_delete(mailbox m);
/* Deletes the maiblox m
Requires: m is an initialized mailboc
Insures: m is deleted, and its memory freed */

#endif
