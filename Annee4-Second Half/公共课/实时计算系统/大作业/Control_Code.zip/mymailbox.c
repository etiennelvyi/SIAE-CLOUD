/*
 * Mailbox of size one with loss
 * (c) Emmanuel Grolleau - 2015
 */
#include "mymailbox.h"
#include <stdlib.h>
#include <string.h>
mailbox mailbox_init(const unsigned msg_size) {
    mailbox m;
	if (!(m=(mailbox)malloc(sizeof(struct s_mailbox)))) return 0; /* Struct allocation */
	if (!((*m).buf=(char *)malloc(msg_size))) return 0; /* Buffer allocation */
	(*m).empty=1; /* Mailbox is empty */
	pthread_mutex_init(&((*m).mutex),0); /* Initialization of the mutex */
	(*m).message_size=msg_size;
	pthread_cond_init (&((*m).not_empty), 0); /* Initialization of the conditional variable */
	return m;
}

int mailbox_receive(mailbox m, char *buf) {
    pthread_mutex_lock (&(*m).mutex);
    /* Mutual exclusion */
	while ((*m).empty) {
		pthread_cond_wait (&(*m).not_empty, &(*m).mutex);
		/* Wait for the mailbox not to be empty */
	}
	memcpy(buf,(*m).buf,(*m).message_size); /* Copying the message in buf */
	(*m).empty=1; /* mailbox is now empty */
	pthread_mutex_unlock (&(*m).mutex); /* End of mutual exclusion */
	return (*m).message_size;
}

int mailbox_send(mailbox m, const char *buf) {
    pthread_mutex_lock (&(*m).mutex);
    /* Mutual exclusion */
	memcpy((*m).buf,buf,(*m).message_size); /* Copyng buf in the mailbox's buf */
	(*m).empty=0; /* The mailbox is not empty */
	pthread_cond_signal (&(*m).not_empty); /* Signaling the conditional variable to release potential waiting task*/
	pthread_mutex_unlock (&(*m).mutex); /* End of mutual exclusion */
	return (*m).message_size;
}

void mailbox_delete(mailbox m) {
    pthread_mutex_lock(&(*m).mutex);
    pthread_cond_destroy(&(*m).not_empty);
    free((*m).buf);
    pthread_mutex_unlock(&(*m).mutex);
    pthread_mutex_destroy(&(*m).mutex);
    free(m);
}
