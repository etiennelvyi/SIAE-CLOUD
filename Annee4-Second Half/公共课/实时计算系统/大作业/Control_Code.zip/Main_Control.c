#include <pthread.h>
#include <time.h>
#include <stdio.h>
#include <conio.h>
#include <semaphore.h>
#include "mymailbox.h"
#include "SharedData.h"
#include "simulator.h"
const int MS_L1=70;
const int MS_L2=100;
const int HIGH=1;
const int LOW=0;
const int NORMAL=0;
const int ALARM1=1;
const int ALARM2=2;

int WaterState =0;
mailbox MB;
void  add_timespec (struct timespec *s,
                   const struct timespec *t1,
                   const struct timespec *t2)
/* s = t1+t2 */
{
 s->tv_sec  = t1->tv_sec  + t2->tv_sec;
 s->tv_nsec = t1->tv_nsec + t2->tv_nsec;
 s->tv_sec += s->tv_nsec/1000000000;
 s->tv_nsec %= 1000000000;
}

void *t1(void * unused) { /* A thread is a function that will be run using pthread_create */
	/* local variables */
	struct timespec release; /* will contain the release date */
	struct timespec period; /* contains the period */
	struct timespec remain; /* used for clock_nanosleep */
	period.tv_nsec=1000000 ; /* le champ en nanosecondes vaut 1 mseconde */
	period.tv_sec=0 ; /* le champ en secondes vaut 0 */
	int R_AlarmState = 0;
	/* initialization */
	clock_gettime(CLOCK_REALTIME,&release); /* release=current time */
	for (;;) { /* do forever */
		/* task body */
		check:
		mailbox_receive(MB,(char*)&R_AlarmState);
		if (R_AlarmState<2)
		{
			
			if(ReadHLS())
			{
				WaterState = HIGH;
				CommandPump(1);
				while(ReadLLS())
				{
				   mailbox_receive(MB,(char*)&R_AlarmState);
				   if (R_AlarmState == 2)
				   {
				   		CommandPump(0);
				   		goto check;
				   }
				}
				WaterState = LOW;
			
			}
			else
			{
				CommandPump(0);
			}
		}
		else 
		{
			CommandPump(0);
		}
		add_timespec(&release, &release, &period); /* computing next release time */
		clock_nanosleep(CLOCK_REALTIME,TIMER_ABSTIME,&release,&remain); /* wait until release time */
	}
}

void *t2(void * unused) { /* A thread is a function that will be run using pthread_create */
	/* local variables */
	struct timespec release2; /* will contain the release date */
	struct timespec period2; /* contains the period */
	struct timespec remain2; /* used for clock_nanosleep */
	period2.tv_nsec=1000000 ; /* le champ en nanosecondes vaut 1 mseconde */
	period2.tv_sec=0 ; /* le champ en secondes vaut 0 */
	int AlarmState =0 ;
	/* initialization */
	clock_gettime(CLOCK_REALTIME,&release2); /* release=current time */
	for (;;) { /* do forever */
		/* task body */
				
		if(ReadMS()>MS_L2)
		{
			AlarmState = ALARM2;
			CommandAlarm(1);
		}
		else if(ReadMS()>=MS_L1&&ReadMS()<=MS_L2)
		{
			AlarmState = ALARM1;
			CommandAlarm(1);
		}
		else
		{
			AlarmState = NORMAL;
			CommandAlarm(0);
		}
		mailbox_send(MB,(char*)&AlarmState);
		add_timespec(&release2, &release2, &period2); /* computing next release time */
		clock_nanosleep(CLOCK_REALTIME,TIMER_ABSTIME,&release2,&remain2); /* wait until release time */
	}
}

void main() {
	
	InitSimu();
	MB=mailbox_init(sizeof(int));
	pthread_t T1,T2;
	pthread_create(&T1, 0,t1,0); 
	pthread_create(&T2, 0,t2,0); 
	pthread_join(T1,0); 
	
	
}
