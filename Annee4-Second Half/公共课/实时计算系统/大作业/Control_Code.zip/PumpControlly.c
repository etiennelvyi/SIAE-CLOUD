#include <pthread.h>
#include <time.h>
#include <stdio.h>
#include <semaphore.h>
#include <stdlib.h>
#include "mymailbox.h"
#include "SharedData.h"
#include "simulator.h"
const int MS_L1=70;
const int MS_L2=100;
const int HIGH=2;
const int MEDIUM=1;
const int LOW=0;
const int NORMAL=0;
const int ALARM1=1;
const int ALARM2=2;

int AlarmState =0 ;
int WaterState =0;

mailbox MB;
sem_t NEWDATA;

void  add_timespec (struct timespec *s,
                   const struct timespec *t1,
                   const struct timespec *t2)
{
 s->tv_sec  = t1->tv_sec  + t2->tv_sec;
 s->tv_nsec = t1->tv_nsec + t2->tv_nsec;
 s->tv_sec += s->tv_nsec/1000000000;
 s->tv_nsec %= 1000000000;
}
//define a waiting function to simulate the delay of the sensor
void wait_a_sec(int sec,int msec)
{
	/* local variables */
	struct timespec release; /* will contain the release date */
	struct timespec period; /* contains the period */
	struct timespec remain; /* used for clock_nanosleep */
	/* initialization */
	period.tv_nsec=msec*1000000 ; /* le champ en nanosecondes vaut 1 mseconde */
	period.tv_sec=sec ; /* le champ en secondes vaut 0 */
	clock_gettime(CLOCK_REALTIME,&release); /* release=current time */
	add_timespec(&release, &release, &period); /* computing next release time */
	clock_nanosleep(CLOCK_REALTIME,TIMER_ABSTIME,&release,&remain); /* wait until release time */
}
//the thread of the pump controller
void *CtrlPump (void * unused) { /* A thread is a function that will be run using pthread_create */
	
	for (;;) { /* do forever */
		/* task body */
		sem_wait(&NEWDATA);
		mailbox_send(MB,(char*)&AlarmState);//send the alarmstate to the alarm controller

		if (AlarmState<2)
		{
			
			if(WaterState == HIGH)
			{
				
				while(WaterState != LOW && AlarmState<2)
				{
				   	CommandPump(1);
				   	mailbox_send(MB,(char*)&AlarmState);  
				}
			}
			else
			{
				CommandPump(0);
			}
		}
		else 
		{
			CommandPump(0);
		}
	}
}

//the thread of the alarm controller
void *CmdAlarm(void * unused) { /* A thread is a function that will be run using pthread_create */
	int R_AlarmState=0;
	
	for (;;) { /* do forever */
		/* task body */
		mailbox_receive(MB,(char*)&R_AlarmState);//get the alarm state from the pump control thread		
		if(R_AlarmState == ALARM2)
		{
			CommandAlarm(1);
		}
		else if(R_AlarmState == ALARM1)
		{
			CommandAlarm(1);
		}
		else 
		{
			CommandAlarm(0);
		}

	}
}

//the thread of getting the methanelevel with delay of 50ms
void *AcqMethaneLevel (void * unused)
{
	while(1)
	{
		
		if(ReadMS()>MS_L2)
		{
			AlarmState = ALARM2;
		}
		else if(ReadMS()>=MS_L1&&ReadMS()<=MS_L2)
		{
			AlarmState = ALARM1;
		}
		else
		{
			AlarmState = NORMAL;
		}
		wait_a_sec(0,50);
		sem_post(&NEWDATA);
	}
}

//the thread of getting the waterlevel with delay of 400ms
void *AcqWaterLevel (void * unused)
{
	
	while(1)
	{
		if(ReadHLS())
		{
			WaterState = HIGH;
		}
		else if(!ReadLLS())
		{
			WaterState = LOW;
		}
		else
		{
			WaterState = MEDIUM;
		}
		wait_a_sec(0,400);
		sem_post(&NEWDATA);
	}

}

void *putonsrc (void * unused)
{
	
	while(1)
	{
		if(WaterState == HIGH)
		{
			printf("WaterLevel is HIGH\n");
		}
		else if(WaterState == LOW)
		{
			printf("WaterLevel is LOW\n");
		}
		else
		{
			printf("WaterLevel is MEDIUM\n");
		}

		if(AlarmState == ALARM2)
		{
			printf("AlarmState is ALARM2\n");
		}
		else if(AlarmState == ALARM1)
		{
			printf("AlarmState is ALARM1\n");
		}
		else
		{
			printf("AlarmState is NORMAL\n");
		}
		wait_a_sec(0,1000);
		system("cls");
	}

}

void main() {
	
	InitSimu();
	MB=mailbox_init(sizeof(int));
	sem_init(&NEWDATA,0,0);
	pthread_t T1,T2,T3,T4,T5;
	pthread_create(&T1, 0,CtrlPump ,0); 
	pthread_create(&T2, 0,CmdAlarm,0); 
	pthread_create(&T3, 0,AcqMethaneLevel,0); 
	pthread_create(&T4, 0,AcqWaterLevel ,0); 
	pthread_create(&T5, 0,putonsrc ,0); 
	pthread_join(T1,0); 	
}
